import { useEffect, useState } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { PageHeader } from "@/components/dashboard/PageHeader";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { supabase } from "@/integrations/supabase/client";
import { CalendarIcon, CalendarCheck, Loader2, Check, X, Clock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

interface Student {
  id: string;
  full_name: string;
  roll_number: string;
  faculty_id: string | null;
}

interface Faculty {
  id: string;
  name: string;
}

interface AttendanceRecord {
  id: string;
  student_id: string;
  status: string;
}

export default function Attendance() {
  const { toast } = useToast();
  const [faculties, setFaculties] = useState<Faculty[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [attendance, setAttendance] = useState<Record<string, string>>({});
  const [existingRecords, setExistingRecords] = useState<AttendanceRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [selectedFaculty, setSelectedFaculty] = useState("");
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());

  useEffect(() => {
    const fetchFaculties = async () => {
      const { data, error } = await supabase.from("faculties").select("id, name").order("name");
      if (error) {
        console.error("Error fetching faculties:", error);
        return;
      }
      setFaculties(data || []);
      setLoading(false);
    };
    fetchFaculties();
  }, []);

  useEffect(() => {
    if (!selectedFaculty) {
      setStudents([]);
      return;
    }

    const fetchStudentsAndAttendance = async () => {
      setLoading(true);
      try {
        const [studentsRes, attendanceRes] = await Promise.all([
          supabase
            .from("students")
            .select("id, full_name, roll_number, faculty_id")
            .eq("faculty_id", selectedFaculty)
            .order("roll_number"),
          supabase
            .from("attendance")
            .select("id, student_id, status")
            .eq("faculty_id", selectedFaculty)
            .eq("date", format(selectedDate, "yyyy-MM-dd")),
        ]);

        if (studentsRes.error) throw studentsRes.error;
        if (attendanceRes.error) throw attendanceRes.error;

        setStudents(studentsRes.data || []);
        setExistingRecords(attendanceRes.data || []);

        // Pre-fill attendance state with existing records
        const attendanceMap: Record<string, string> = {};
        attendanceRes.data?.forEach((record) => {
          attendanceMap[record.student_id] = record.status;
        });
        setAttendance(attendanceMap);
      } catch (error) {
        console.error("Error fetching data:", error);
        toast({
          title: "Error",
          description: "Failed to fetch attendance data",
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };

    fetchStudentsAndAttendance();
  }, [selectedFaculty, selectedDate]);

  const handleStatusChange = (studentId: string, status: string) => {
    setAttendance((prev) => ({
      ...prev,
      [studentId]: prev[studentId] === status ? "" : status,
    }));
  };

  const handleSaveAttendance = async () => {
    if (!selectedFaculty) return;

    const records = Object.entries(attendance)
      .filter(([, status]) => status)
      .map(([studentId, status]) => ({
        student_id: studentId,
        faculty_id: selectedFaculty,
        date: format(selectedDate, "yyyy-MM-dd"),
        status,
      }));

    if (records.length === 0) {
      toast({
        title: "No attendance marked",
        description: "Please mark attendance for at least one student",
        variant: "destructive",
      });
      return;
    }

    setSaving(true);
    try {
      // Delete existing records for the date
      await supabase
        .from("attendance")
        .delete()
        .eq("faculty_id", selectedFaculty)
        .eq("date", format(selectedDate, "yyyy-MM-dd"));

      // Insert new records
      const { error } = await supabase.from("attendance").insert(records);
      if (error) throw error;

      toast({
        title: "Attendance saved",
        description: `Saved attendance for ${records.length} students`,
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to save attendance",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const markAll = (status: string) => {
    const newAttendance: Record<string, string> = {};
    students.forEach((student) => {
      newAttendance[student.id] = status;
    });
    setAttendance(newAttendance);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "present":
        return <Check className="w-4 h-4" />;
      case "absent":
        return <X className="w-4 h-4" />;
      case "late":
        return <Clock className="w-4 h-4" />;
      default:
        return null;
    }
  };

  return (
    <DashboardLayout>
      <PageHeader
        title="Attendance"
        description="Mark and manage student attendance"
      />

      {/* Filters */}
      <div className="card-elevated p-6 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="space-y-2">
            <Label>Select Faculty</Label>
            <Select value={selectedFaculty} onValueChange={setSelectedFaculty}>
              <SelectTrigger>
                <SelectValue placeholder="Choose a faculty" />
              </SelectTrigger>
              <SelectContent>
                {faculties.map((faculty) => (
                  <SelectItem key={faculty.id} value={faculty.id}>
                    {faculty.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Select Date</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-full justify-start text-left font-normal">
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {format(selectedDate, "PPP")}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={(date) => date && setSelectedDate(date)}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>
          <div className="flex items-end">
            <Button onClick={handleSaveAttendance} disabled={saving || !selectedFaculty} className="w-full">
              {saving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Save Attendance
            </Button>
          </div>
        </div>
      </div>

      {!selectedFaculty ? (
        <div className="card-elevated p-12 text-center">
          <CalendarCheck className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium text-foreground">Select a Faculty</h3>
          <p className="text-muted-foreground mt-1">
            Choose a faculty to mark attendance
          </p>
        </div>
      ) : loading ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      ) : students.length === 0 ? (
        <div className="card-elevated p-12 text-center">
          <CalendarCheck className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium text-foreground">No Students</h3>
          <p className="text-muted-foreground mt-1">
            No students enrolled in this faculty
          </p>
        </div>
      ) : (
        <>
          {/* Quick Actions */}
          <div className="flex gap-3 mb-4">
            <Button variant="outline" size="sm" onClick={() => markAll("present")}>
              <Check className="w-4 h-4 mr-1 text-success" />
              Mark All Present
            </Button>
            <Button variant="outline" size="sm" onClick={() => markAll("absent")}>
              <X className="w-4 h-4 mr-1 text-destructive" />
              Mark All Absent
            </Button>
          </div>

          <div className="card-elevated overflow-hidden">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Roll Number</th>
                  <th>Student Name</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {students.map((student) => (
                  <tr key={student.id} className="animate-fade-in">
                    <td className="font-medium">{student.roll_number}</td>
                    <td>{student.full_name}</td>
                    <td>
                      <div className="flex gap-2">
                        <Button
                          variant={attendance[student.id] === "present" ? "default" : "outline"}
                          size="sm"
                          className={cn(
                            attendance[student.id] === "present" &&
                              "bg-success hover:bg-success/90 text-success-foreground"
                          )}
                          onClick={() => handleStatusChange(student.id, "present")}
                        >
                          {getStatusIcon("present")}
                          <span className="ml-1">Present</span>
                        </Button>
                        <Button
                          variant={attendance[student.id] === "absent" ? "default" : "outline"}
                          size="sm"
                          className={cn(
                            attendance[student.id] === "absent" &&
                              "bg-destructive hover:bg-destructive/90"
                          )}
                          onClick={() => handleStatusChange(student.id, "absent")}
                        >
                          {getStatusIcon("absent")}
                          <span className="ml-1">Absent</span>
                        </Button>
                        <Button
                          variant={attendance[student.id] === "late" ? "default" : "outline"}
                          size="sm"
                          className={cn(
                            attendance[student.id] === "late" &&
                              "bg-warning hover:bg-warning/90 text-warning-foreground"
                          )}
                          onClick={() => handleStatusChange(student.id, "late")}
                        >
                          {getStatusIcon("late")}
                          <span className="ml-1">Late</span>
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </DashboardLayout>
  );
}
