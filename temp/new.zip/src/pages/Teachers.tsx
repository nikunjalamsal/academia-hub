import { useEffect, useState } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { PageHeader } from "@/components/dashboard/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { Plus, Users, Loader2, Pencil, Trash2, Search, LinkIcon } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Teacher {
  id: string;
  full_name: string;
  email: string;
  phone: string | null;
  employee_id: string;
  specialization: string | null;
}

interface Faculty {
  id: string;
  name: string;
}

interface TeacherAssignment {
  teacher_id: string;
  faculty_id: string;
  faculties: { name: string };
}

export default function Teachers() {
  const { toast } = useToast();
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [faculties, setFaculties] = useState<Faculty[]>([]);
  const [assignments, setAssignments] = useState<TeacherAssignment[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [assignDialogOpen, setAssignDialogOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editingTeacher, setEditingTeacher] = useState<Teacher | null>(null);
  const [assigningTeacher, setAssigningTeacher] = useState<Teacher | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedFaculty, setSelectedFaculty] = useState("");
  const [formData, setFormData] = useState({
    full_name: "",
    email: "",
    phone: "",
    employee_id: "",
    specialization: "",
  });

  const fetchData = async () => {
    try {
      const [teachersRes, facultiesRes, assignmentsRes] = await Promise.all([
        supabase.from("teachers").select("*").order("full_name"),
        supabase.from("faculties").select("id, name").order("name"),
        supabase.from("teacher_faculty_assignments").select("teacher_id, faculty_id, faculties(name)"),
      ]);

      if (teachersRes.error) throw teachersRes.error;
      if (facultiesRes.error) throw facultiesRes.error;
      if (assignmentsRes.error) throw assignmentsRes.error;

      setTeachers(teachersRes.data || []);
      setFaculties(facultiesRes.data || []);
      setAssignments(assignmentsRes.data as TeacherAssignment[] || []);
    } catch (error) {
      console.error("Error fetching data:", error);
      toast({
        title: "Error",
        description: "Failed to fetch teachers",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.full_name.trim() || !formData.email.trim() || !formData.employee_id.trim()) return;

    setSaving(true);
    try {
      const teacherData = {
        full_name: formData.full_name.trim(),
        email: formData.email.trim(),
        phone: formData.phone.trim() || null,
        employee_id: formData.employee_id.trim(),
        specialization: formData.specialization.trim() || null,
      };

      if (editingTeacher) {
        const { error } = await supabase
          .from("teachers")
          .update(teacherData)
          .eq("id", editingTeacher.id);

        if (error) throw error;
        toast({ title: "Teacher updated successfully" });
      } else {
        const { error } = await supabase.from("teachers").insert(teacherData);
        if (error) throw error;
        toast({ title: "Teacher added successfully" });
      }

      setDialogOpen(false);
      resetForm();
      fetchData();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to save teacher",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const handleAssignFaculty = async () => {
    if (!assigningTeacher || !selectedFaculty) return;

    setSaving(true);
    try {
      const { error } = await supabase.from("teacher_faculty_assignments").insert({
        teacher_id: assigningTeacher.id,
        faculty_id: selectedFaculty,
      });

      if (error) throw error;
      toast({ title: "Faculty assigned successfully" });
      setAssignDialogOpen(false);
      setSelectedFaculty("");
      setAssigningTeacher(null);
      fetchData();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to assign faculty",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const handleRemoveAssignment = async (teacherId: string, facultyId: string) => {
    try {
      const { error } = await supabase
        .from("teacher_faculty_assignments")
        .delete()
        .eq("teacher_id", teacherId)
        .eq("faculty_id", facultyId);

      if (error) throw error;
      toast({ title: "Assignment removed" });
      fetchData();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to remove assignment",
        variant: "destructive",
      });
    }
  };

  const resetForm = () => {
    setFormData({
      full_name: "",
      email: "",
      phone: "",
      employee_id: "",
      specialization: "",
    });
    setEditingTeacher(null);
  };

  const handleEdit = (teacher: Teacher) => {
    setEditingTeacher(teacher);
    setFormData({
      full_name: teacher.full_name,
      email: teacher.email,
      phone: teacher.phone || "",
      employee_id: teacher.employee_id,
      specialization: teacher.specialization || "",
    });
    setDialogOpen(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Are you sure you want to delete this teacher?")) return;

    try {
      const { error } = await supabase.from("teachers").delete().eq("id", id);
      if (error) throw error;
      toast({ title: "Teacher deleted successfully" });
      fetchData();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to delete teacher",
        variant: "destructive",
      });
    }
  };

  const getTeacherAssignments = (teacherId: string) => {
    return assignments.filter((a) => a.teacher_id === teacherId);
  };

  const getAvailableFaculties = (teacherId: string) => {
    const assignedIds = assignments
      .filter((a) => a.teacher_id === teacherId)
      .map((a) => a.faculty_id);
    return faculties.filter((f) => !assignedIds.includes(f.id));
  };

  const filteredTeachers = teachers.filter(
    (teacher) =>
      teacher.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      teacher.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      teacher.employee_id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <DashboardLayout>
      <PageHeader
        title="Teachers"
        description="Manage faculty members and their assignments"
        actions={
          <Dialog open={dialogOpen} onOpenChange={(open) => {
            setDialogOpen(open);
            if (!open) resetForm();
          }}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Add Teacher
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>
                  {editingTeacher ? "Edit Teacher" : "Add New Teacher"}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="full_name">Full Name</Label>
                  <Input
                    id="full_name"
                    placeholder="Enter teacher name"
                    value={formData.full_name}
                    onChange={(e) =>
                      setFormData({ ...formData, full_name: e.target.value })
                    }
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="teacher@example.com"
                    value={formData.email}
                    onChange={(e) =>
                      setFormData({ ...formData, email: e.target.value })
                    }
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone</Label>
                  <Input
                    id="phone"
                    placeholder="Phone number"
                    value={formData.phone}
                    onChange={(e) =>
                      setFormData({ ...formData, phone: e.target.value })
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="employee_id">Employee ID</Label>
                  <Input
                    id="employee_id"
                    placeholder="e.g., EMP001"
                    value={formData.employee_id}
                    onChange={(e) =>
                      setFormData({ ...formData, employee_id: e.target.value })
                    }
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="specialization">Specialization</Label>
                  <Input
                    id="specialization"
                    placeholder="e.g., Data Science"
                    value={formData.specialization}
                    onChange={(e) =>
                      setFormData({ ...formData, specialization: e.target.value })
                    }
                  />
                </div>
                <div className="flex justify-end gap-3">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button type="submit" disabled={saving}>
                    {saving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                    {editingTeacher ? "Update" : "Add Teacher"}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        }
      />

      {/* Assign Faculty Dialog */}
      <Dialog open={assignDialogOpen} onOpenChange={setAssignDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Assign Faculty to {assigningTeacher?.full_name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Select Faculty</Label>
              <Select value={selectedFaculty} onValueChange={setSelectedFaculty}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a faculty" />
                </SelectTrigger>
                <SelectContent>
                  {assigningTeacher &&
                    getAvailableFaculties(assigningTeacher.id).map((faculty) => (
                      <SelectItem key={faculty.id} value={faculty.id}>
                        {faculty.name}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex justify-end gap-3">
              <Button variant="outline" onClick={() => setAssignDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleAssignFaculty} disabled={saving || !selectedFaculty}>
                {saving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                Assign
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Search */}
      <div className="mb-6">
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search teachers..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9"
          />
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      ) : filteredTeachers.length === 0 ? (
        <div className="card-elevated p-12 text-center">
          <Users className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium text-foreground">No teachers found</h3>
          <p className="text-muted-foreground mt-1">
            {teachers.length === 0
              ? "Get started by adding your first teacher"
              : "No teachers match your search"}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {filteredTeachers.map((teacher) => (
            <div key={teacher.id} className="card-elevated p-6 animate-fade-in">
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary font-semibold">
                    {teacher.full_name.charAt(0)}
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">{teacher.full_name}</h3>
                    <p className="text-sm text-muted-foreground">{teacher.email}</p>
                    <p className="text-sm text-muted-foreground">ID: {teacher.employee_id}</p>
                    {teacher.specialization && (
                      <p className="text-sm text-accent mt-1">{teacher.specialization}</p>
                    )}
                  </div>
                </div>
                <div className="flex gap-1">
                  <Button variant="ghost" size="icon" onClick={() => handleEdit(teacher)}>
                    <Pencil className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-destructive hover:text-destructive"
                    onClick={() => handleDelete(teacher.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* Assigned Faculties */}
              <div className="mt-4 pt-4 border-t border-border">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-muted-foreground">Assigned Faculties</span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setAssigningTeacher(teacher);
                      setAssignDialogOpen(true);
                    }}
                  >
                    <LinkIcon className="w-3 h-3 mr-1" />
                    Assign
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {getTeacherAssignments(teacher.id).length === 0 ? (
                    <span className="text-sm text-muted-foreground">No faculties assigned</span>
                  ) : (
                    getTeacherAssignments(teacher.id).map((assignment) => (
                      <Badge
                        key={assignment.faculty_id}
                        variant="secondary"
                        className="cursor-pointer hover:bg-destructive hover:text-destructive-foreground"
                        onClick={() => handleRemoveAssignment(teacher.id, assignment.faculty_id)}
                      >
                        {assignment.faculties.name} ×
                      </Badge>
                    ))
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </DashboardLayout>
  );
}
