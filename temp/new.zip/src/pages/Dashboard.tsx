import { useEffect, useState } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { PageHeader } from "@/components/dashboard/PageHeader";
import { StatCard } from "@/components/dashboard/StatCard";
import { supabase } from "@/integrations/supabase/client";
import { GraduationCap, Users, BookOpen, ClipboardList, CalendarCheck, TrendingUp } from "lucide-react";
import { useAuth } from "@/context/AuthContext";


interface DashboardStats {
  totalStudents: number;
  totalTeachers: number;
  totalFaculties: number;
  totalAssignments: number;
  todayAttendance: number;
}

export default function Dashboard() {
  const { role, loading: authLoading } = useAuth();
  if (authLoading) {
    return <div>Loading...</div>;
  }  
  const [stats, setStats] = useState<DashboardStats>({
    totalStudents: 0,
    totalTeachers: 0,
    totalFaculties: 0,
    totalAssignments: 0,
    todayAttendance: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const [studentsRes, teachersRes, facultiesRes, assignmentsRes, attendanceRes] = await Promise.all([
          supabase.from("students").select("id", { count: "exact", head: true }),
          supabase.from("teachers").select("id", { count: "exact", head: true }),
          supabase.from("faculties").select("id", { count: "exact", head: true }),
          supabase.from("assignments").select("id", { count: "exact", head: true }),
          supabase.from("attendance").select("id", { count: "exact", head: true }).eq("date", new Date().toISOString().split("T")[0]),
        ]);

        setStats({
          totalStudents: studentsRes.count || 0,
          totalTeachers: teachersRes.count || 0,
          totalFaculties: facultiesRes.count || 0,
          totalAssignments: assignmentsRes.count || 0,
          todayAttendance: attendanceRes.count || 0,
        });
      } catch (error) {
        console.error("Error fetching stats:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  return (
    <DashboardLayout>
      <PageHeader
        title="Dashboard"
        description="Welcome to Vinayak Siddha College Portal"
      />

        {role === "admin" && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <StatCard
          title="Total Students"
          value={loading ? "..." : stats.totalStudents}
          icon={<GraduationCap className="w-6 h-6" />}
          description="Enrolled students"
        />
        <StatCard
          title="Total Teachers"
          value={loading ? "..." : stats.totalTeachers}
          icon={<Users className="w-6 h-6" />}
          description="Active faculty members"
        />
        <StatCard
          title="Faculties"
          value={loading ? "..." : stats.totalFaculties}
          icon={<BookOpen className="w-6 h-6" />}
          description="Departments"
        />
        <StatCard
          title="Assignments"
          value={loading ? "..." : stats.totalAssignments}
          icon={<ClipboardList className="w-6 h-6" />}
          description="Active assignments"
        />
        <StatCard
          title="Today's Attendance"
          value={loading ? "..." : stats.todayAttendance}
          icon={<CalendarCheck className="w-6 h-6" />}
          description="Records today"
        />
        <StatCard
          title="System Status"
          value="Active"
          icon={<TrendingUp className="w-6 h-6" />}
          description="All systems operational"
        />
        </div>
        )}



      {/* Quick Actions */}
      {(role === "admin" || role === "teacher") && (
      <div className="mt-8">
        <h2 className="text-xl font-semibold text-foreground mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <QuickActionCard
            title="Add Student"
            description="Register a new student"
            href="/students"
            icon={<GraduationCap className="w-5 h-5" />}
          />
          <QuickActionCard
            title="Add Teacher"
            description="Add new faculty member"
            href="/teachers"
            icon={<Users className="w-5 h-5" />}
          />
          <QuickActionCard
            title="Take Attendance"
            description="Mark today's attendance"
            href="/attendance"
            icon={<CalendarCheck className="w-5 h-5" />}
          />
          <QuickActionCard
            title="Create Assignment"
            description="Post new assignment"
            href="/assignments"
            icon={<ClipboardList className="w-5 h-5" />}
          />
        </div>
      </div>
      )}
    </DashboardLayout>
  );
}

interface QuickActionCardProps {
  title: string;
  description: string;
  href: string;
  icon: React.ReactNode;
}

function QuickActionCard({ title, description, href, icon }: QuickActionCardProps) {
  return (
    <a
      href={href}
      className="card-elevated p-4 flex items-center gap-4 hover:shadow-lg transition-all duration-300 hover:-translate-y-0.5 group"
    >
      <div className="p-3 rounded-lg bg-secondary/20 text-secondary group-hover:bg-secondary group-hover:text-secondary-foreground transition-colors">
        {icon}
      </div>
      <div>
        <h3 className="font-medium text-foreground">{title}</h3>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>
    </a>
  );
}
